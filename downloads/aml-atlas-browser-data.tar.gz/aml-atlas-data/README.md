# Pediatric AML atlas browser — processed data

Every table behind https://gawadlab.org/aml-atlas/. These are **processed,
figure-level matrices**, not the primary sequencing data.

For the **single-cell count matrices**, use the Alex's Lemonade Stand
Single-cell Pediatric Cancer Atlas, project **SCPCP000007**:
https://scpca.alexslemonade.org/projects/SCPCP000007 (30 samples, scRNA-seq + CITE-seq).

## Files

| File | Rows | Contents |
|---|---|---|
| `Figure_2/fig2A_umap_cells.csv` | 96,627 | one row per cell: barcode, UMAP1/2, compartment, cell type, leukemic state, grid bin |
| `Figure_2/fig2A_bins.csv` | 6,005 | grid squares over the UMAP: centre and cell count |
| `Figure_2/fig2A_gene_bin_expr.csv` | 936,506 | mean log1p(CPM) per gene per grid bin, for the 1,311 genes detected in >=25 cells |
| `Figure_5/fig5A_top15.csv` | 1,704 | the surfaceome screen: % leukemic cells positive, patients above 20%, % normal HSPC, % myeloid progenitors, composite score, rank |
| `Figure_5/fig5A_funnel.csv` | - | screen funnel stage counts |
| `Figure_5/fig5C_headtohead.csv` | 48 | established antigens profiled side by side |
| `Figure_5/fig5D_ls.csv` | 969 | % positive per leukemic state, 19 antigens |
| `Figure_5/fig5D_cyto.csv` | 266 | % positive per cytogenetic subtype, 19 antigens |
| `Figure_5/fig5F_meta_all.csv` | 12 | % patients targetable, pediatric TARGET bulk |
| `Figure_5/fig5F_adult_beataml_meta.csv` | 12 | % patients targetable, adult Beat AML |
| `Figure_S23/adult_scrna_overall.csv` | 12 | % cells positive, independent adult single-cell cohort |
| `Figure_6/fig6D_radar.csv` | 12 | five-axis profile per antigen |
| `Figure_6/fig6tox_hema.csv` | 276 | normal marrow cell types, % positive |
| `Figure_6/fig6tox_organ.csv` | 648 | vital organ cell types, % positive |
| `Figure_7/fig7_allpairs.csv` | 78 | single antigens and all 66 pairs: depth, breadth, marrow toxicity |
| `Figure_S16/funnel_ls_specific*.csv` | 10,224 | the same screen re-run within poor-prognosis contexts, plus their composition |

## Other data used by the study

- Bulk RNA-seq for survival validation: TARGET-AML via the Genomic Data Commons (dbGaP phs000465)
- Adult bulk validation: the Beat AML public release

Licence: CC BY 4.0. Please cite the paper.
