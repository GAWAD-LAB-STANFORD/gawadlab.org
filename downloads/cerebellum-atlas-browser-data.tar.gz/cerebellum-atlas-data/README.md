# Developing cerebellum atlas browser — processed data

The tables behind https://gawadlab.org/cerebellum-atlas/, derived from
Carter RA *et al.*, "A Single-Cell Transcriptional Atlas of the Developing
Murine Cerebellum", *Current Biology* 28, 2910-2920 (2018).
DOI 10.1016/j.cub.2018.07.062 · PMID 30220501. Data submitted by St. Jude
Children's Research Hospital.

## What is and is not available upstream

**There is no deposited count matrix for this dataset.** ENA
[PRJEB23051](https://www.ebi.ac.uk/ena/browser/view/PRJEB23051) holds 22 aligned
BAMs (~595 GB, 13 timepoints x 2 replicates) and nothing else — no FASTQs and no
processed matrices. Recovering raw integer counts means
`cellranger bamtofastq` on those BAMs followed by `cellranger count`.

Everything here is therefore derived from **log-normalized** expression, and is
labelled as such. None of these files contain counts.

## Files

| File | Rows | Contents |
|---|---|---|
| `cells.csv` | 40,253 | one row per cell: t-SNE coordinates, cell type, timepoint, grid square |
| `grid_bins.csv` | 1,355 | the square grid over the embedding: centre and cell count |
| `gene_stats_by_group.csv.gz` | 21,657 | per gene, the **mean log-normalized expression** and the **percent of cells with any detected transcript**, within each of the 8 cell types and each of the 13 timepoints. Column names are `ct_mean\|<type>`, `ct_pct\|<type>`, `tp_mean\|<timepoint>`, `tp_pct\|<timepoint>`. Means are taken over every cell in the group, so cells with no detected transcript count as zero. |
| `group_sizes.csv` | 21 | how many cells each cell type and each timepoint holds |

The browser also carries a dense per-gene, per-grid-square expression matrix for
the 15,624 genes with enough signal to map. It is packed as uint8 for the
browser; the same numbers can be rebuilt for any gene from `cells.csv` plus the
source database.

## Cell types and timepoints

GABA (4,551), Glia (3,378), Granule (10,745), Interneuron (888), NTZ (2,842),
Other (7,400), Progenitor (9,206), Purkinje (1,243).

E10, E11, E12, E13, E14, E15, E16, E17, E18, P0, P4, P7, P10.

## Sanity checks

Canonical markers land where they should: Pcp2 and Calb1 peak in Purkinje cells
(51x and 17x over the next cell type), Gfap in glia, Pax6 in granule cells,
Ptf1a in the GABAergic lineage. Gabra6 is absent, as expected — it switches on
after this dataset's P10 endpoint.

Please cite Carter *et al.* 2018.
