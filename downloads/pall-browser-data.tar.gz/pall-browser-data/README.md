# Pediatric ALL treatment-resistance browser — processed data

The tables behind https://gawadlab.org/pall-resistance/, from Pang, Prieto
*et al.*, "Single-Cell Sequencing Reveals Extensive Genetic Diversity
Underlying Pediatric ALL Treatment Complexity".

These are **processed, figure-level tables**, not primary sequencing data. Raw
reads come from identifiable patient material and are going to NCBI SRA and
dbGaP under controlled access, with processed matrices in Mendeley Data;
accessions will be listed on the paper's publication.

## Files

| File | Rows | Contents |
|---|---|---|
| `mutation_burden_bulk_vs_singlecell.csv` | 31 | per bulk sample and per single cell: total, unique and shared somatic SNVs, detection sensitivity, and sensitivity-corrected mutations per Mb. 5 bulk, 26 cells, 5 patients. |
| `paediatric_tumour_burden_reference.csv` | 961 | published survey of paediatric tumours: SNVs and indels per Mb across 24 cancer types, the backdrop ALL is compared against |
| `ras_mutations.tsv` | 32 | activating KRAS and NRAS mutations found by error-corrected sequencing: patient, codon, amino-acid change, allele frequency |
| `drug_response_five_patients.tsv` | 49 x 79 | mutant allele frequency (%) per sample per recurrent mutation, five patients across DMSO, high-dose prednisolone, high-dose daunorubicin and the diagnostic bulk |
| `drug_response_variants.tsv` | 1,389 | the same experiment at variant level: coordinates, ref/alt read counts, allele frequency, gene and protein change |
| `drug_response_SJETV077.tsv` | 575 | a separate single-patient experiment: mean allele frequency per mutation across nine ex vivo conditions covering six agents plus controls |
| `single_cells_cnv_and_markers.csv` | 115 | per cell: five binary copy-number deletion calls and six index-sorted surface-marker intensities, for the paired pretreatment (4272) and post-treatment (4295) samples |
| `single_cells_clone_assignment.tsv` | 116 | per cell copy-number cluster. Uses CR-only line endings. |
| `single_cells_genotypes.csv` | 113 x 31 | per cell presence or absence of each somatic variant |
| `gene_recurrence.csv` | 29 | per gene: coding length, nonsynonymous events, recurrence above the coding-size expectation, relapse frequency |
| `gene_recurrence_full_stats.csv` | 29 | the same with expected counts, dN/dS and Poisson statistics |
| `alphamissense_observed_variants.csv` | 1,957 | AlphaMissense pathogenicity for every observed missense variant, by gene, gene class, timepoint and source study |

## Reading notes

- `mutation_burden_bulk_vs_singlecell.csv` and `paediatric_tumour_burden_reference.csv`
  carry a UTF-8 byte-order mark and CRLF line endings.
- `single_cells_clone_assignment.tsv` uses CR-only line endings, so `wc -l`
  under-reports it by one row. It lists 116 cells while the CNV table lists 115;
  two cells in the CNV table have no cluster assignment.
- Two genes in `gene_recurrence.csv` (FAM71A, LINC00578) have no coding length
  and therefore no size-corrected recurrence.
- The recurrence and pathogenicity axes draw on different cohort sets, so a
  gene's pair of values is not derived from identical samples.

Please cite the paper.
