CellChat cell-cell communication, pediatric AML single-cell atlas
=================================================================

What this is
------------
Ligand-receptor communication inferred with CellChat 2.2.0.9001 over all
96,627 cells of the pediatric AML atlas (28 children with AML, 2 healthy
bone-marrow donors). Only links reaching p < 0.05 by permutation are
included here: 933,682 of the 4,165,145 non-zero links computed.

Cell groups (75)
----------------
  49  leukemic states, LS_1 to LS_49
   1  "AML (unassigned)" - the 12,942 leukemic cells whose cluster did not
      clear the Jaccard >= 0.35 stability cut, kept together and labelled
      rather than dropped, so no leukemic cell leaves the analysis
  25  annotated non-leukemic cell types

cellchat_group_sizes.csv gives the cell count of each group.

How it was run
--------------
Expression is log1p(CPM) from raw counts, the same normalisation used for
the atlas expression export. Communication probability was computed with
CellChat defaults matching the published CD96 analysis:

  computeCommunProb(type = "truncatedMean", trim = 0, raw.use = TRUE,
                    population.size = TRUE)
  filterCommunication(min.cells = 100)

The published CD96 analysis in the paper was run per sample over 8 coarse
compartments. This run is cohort-level over 75 groups, because at this
resolution most patients contribute no cells to most states. The
probability settings are identical, so magnitudes are comparable, but
per-sample variation is not represented here.

The 100-cell floor removes links involving LS_49 (15 cells) and
Macrophage (78 cells). The paper used a floor of 10, appropriate for its
per-sample design.

Columns of cellchat_significant_links.csv.gz
--------------------------------------------
  source    sending cell group
  target    receiving cell group
  name      ligand-receptor pair, e.g. CD96_PVR
  prob      CellChat communication probability
  pval      permutation p-value (all rows < 0.05)
  level     always "LR" in this file
  pathway   CellChatDB signalling pathway the pair belongs to

Reading the numbers
-------------------
Communication probability rises with the number of cells in a group as
well as with expression, so a large group outranking a small one is not by
itself evidence that it signals more per cell. Probabilities are
comparable between rows of this table and not against another study.

Reproduction check
------------------
CD96, the pathway reported in the paper, has 2,719 significant links here,
79.3% of them sent by a leukemic group. CellChatDB encodes CD96 as the
ligand, so AML-as-sender is the direction the published figure reports.

cc_gene_map.csv.gz
------------------
Which genes take part in which interaction, taken from CellChatDB with
receptor and ligand complexes expanded into their subunit genes, so a gene
can be found even when it is only one subunit of a complex.

  interaction_name   matches the "name" column of the links table
  gene               HGNC symbol
  role               ligand or receptor

8,978 rows over 1,383 genes and all 3,233 CellChatDB interactions. Note how
few genes this is: the atlas quantifies 21,895 genes and 975 of them appear
here, so most genes are neither a ligand nor a receptor in CellChatDB and
carry no interactions at all. CD33 and TP53 are examples.
